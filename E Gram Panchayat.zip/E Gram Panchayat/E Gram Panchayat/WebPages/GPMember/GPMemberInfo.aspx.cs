﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;

namespace E_Gram_Panchayat.WebPages.GPMember
{
    public partial class GPMemberInfo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                lblMobile.Text = Session["UserID"].ToString();
                pagerefresh();
            }
        }


        private void pagerefresh()
        {
            string sql = "select * from tblGramPanchayath where Mobile='" + lblMobile.Text.Trim() + "'";
            SqlDataReader dr = Database.getDataReader(sql);
            if (dr.Read())
            {
                lblID.Text = dr[0].ToString().Trim();
                lblGramPanchayath.Text = dr[1].ToString().Trim();
                lblVillageArea.Text = dr[2].ToString().Trim();
                lblTaluk.Text = dr[3].ToString().Trim();
                lblDistrict.Text = dr[4].ToString().Trim();
                lblGPMember.Text = dr[5].ToString().Trim();
                lblMobile.Text = dr[6].ToString().Trim();
                lblAvailableFund.Text = dr[7].ToString().Trim();
            }
            dr.Close();

        }

    }
}