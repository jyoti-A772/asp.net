﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;

namespace E_Gram_Panchayat.WebPages.GPMember
{
    public partial class GPMemberComplaintsDetails : System.Web.UI.Page
    {
        readyclass obj = new readyclass();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lblID.Text = Request.QueryString["ID"].ToString();

                fillComplaintDetails();

                fillGramPanchayathDetails();
            }
        }

        private void fillComplaintDetails()
        {
            string sql = "Select * from tblComplaints where ID='" + lblID.Text.Trim() + "'";
            SqlDataReader dr = Database.getDataReader(sql);
            if (dr.Read())
            {
                lblID.Text = dr["ID"].ToString().Trim();
                lblWorkID.Text = dr["WorkID"].ToString().Trim();
                lblSubject.Text = dr["Subject"].ToString().Trim();
                lblDescription.Text = dr["Description"].ToString().Trim();
                imgComplaint.ImageUrl = dr["Pic"].ToString().Trim();
                lblStatus.Text = dr["Status"].ToString().Trim();
                lblMobile.Text = dr["GPID"].ToString().Trim();
            }
            dr.Close();
        }


        private void fillGramPanchayathDetails()
        {
            string sql = "Select * from tblGramPanchayath where Mobile='" + lblMobile.Text.Trim() + "'";
            SqlDataReader dr = Database.getDataReader(sql);
            if (dr.Read())
            {
                lblGramPanchayath.Text = dr["GramPanchayath"].ToString().Trim();
                lblVillageArea.Text = dr["VillageArea"].ToString().Trim();
                lblTaluk.Text = dr["Taluk"].ToString().Trim();
                lblDistrict.Text = dr["District"].ToString().Trim();
                lblGPMember.Text = dr["GPMember"].ToString().Trim();
                lblMobile.Text = dr["Mobile"].ToString().Trim();
            }
            dr.Close();
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("GPMemberComplaintsList.aspx");
        }
    }
}