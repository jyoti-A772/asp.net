﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace E_Gram_Panchayat.WebPages.GPMember
{
    public partial class GPMemberFundsWorkList : System.Web.UI.Page
    {
        readyclass obj = new readyclass();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string sql = "Select distinct(Status) from tblUtilizedFunds where GPID='" + Session["UserID"].ToString() + "'";
                obj.filllist(ddlStatus, sql);
            }
        }

        protected void ddlStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sql = "Select * from tblUtilizedFunds where GPID='" + Session["UserID"].ToString() + "' and Status='" + ddlStatus.SelectedValue + "'";
            obj.fill(grdUtilizedFunds, sql, lblerror);
        }
    }
}