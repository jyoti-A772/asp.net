﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;

namespace E_Gram_Panchayat.WebPages.GPMember
{
    public partial class GPMemberFundsList : System.Web.UI.Page
    {
        readyclass obj = new readyclass();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                fillAvailableAmount();

                fillFundList();

                fillUtilizedFundList();
            }
        }

        private void fillAvailableAmount()
        {
            string sql = "select AvailableFund from tblGramPanchayath where Mobile='" + Session["UserID"].ToString() + "'";
            SqlDataReader dr = Database.getDataReader(sql);
            if (dr.Read())
            {
                lblAvailableFund.Text = dr[0].ToString().Trim();
            }
            dr.Close();
        }

        private void fillFundList()
        {
            string sql = "Select * from tblFunds where GPID='" + Session["UserID"].ToString() + "'";
            obj.fill(grdFunds, sql, lblerror);
        }

        private void fillUtilizedFundList()
        {
            string sql = "Select * from tblUtilizedFunds where GPID='" + Session["UserID"].ToString() + "'";
            obj.fill(grdUtilizedFunds, sql, lblerror);
        }

        protected void btnUtilizeFund_Click(object sender, EventArgs e)
        {
            Response.Redirect("GPMemberUtilizeFundAdd.aspx");
        }
    }
}