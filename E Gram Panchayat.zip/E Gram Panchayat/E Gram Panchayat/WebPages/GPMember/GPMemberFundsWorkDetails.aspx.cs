﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;

namespace E_Gram_Panchayat.WebPages.GPMember
{
    public partial class GPMemberFundsWorkDetails : System.Web.UI.Page
    {
        readyclass obj = new readyclass();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lblID.Text = Request.QueryString["ID"].ToString();

                fillUtilizedFundDetails();

                fillWOrkStatus();
            }
        }

        private void fillUtilizedFundDetails()
        {
            string sql = "Select * from tblUtilizedFunds where ID='" + lblID.Text.Trim() + "'";
            SqlDataReader dr = Database.getDataReader(sql);
            if (dr.Read())
            {
                lblID.Text = dr[0].ToString().Trim();
                lblGramPanchayath.Text = dr[1].ToString().Trim();
                lblGPID.Text = dr[2].ToString().Trim();
                lblCategory.Text = dr[3].ToString().Trim();
                lblWorkName.Text = dr[4].ToString().Trim();
                lblUtilizedAmount.Text = dr[5].ToString().Trim();
                lblUtilizedDate.Text = DateTime.Parse(dr[6].ToString().Trim()).ToShortDateString();
                lblStatus.Text = dr[7].ToString().Trim();
            }
            dr.Close();

            if (lblStatus.Text == "Running")
            {
                btnAdd.Visible = true;
                btnCompleted.Visible = true;
            }
            else
            {
                btnAdd.Visible = false;
                btnCompleted.Visible = false;
            }
        }

        private void fillWOrkStatus()
        {
            string sql = "Select * from tblWorkStatus where WorkID='" + lblID.Text.Trim() + "'";
            obj.fill(grdWorkPics, sql, lblerror);
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            Response.Redirect("GPMemberWorkStatusAdd.aspx?WorkID="+lblID.Text.Trim());
        }

        protected void btnCompleted_Click(object sender, EventArgs e)
        {
            string sql1 = "Update tblUtilizedFunds SET ";
            sql1 = sql1 + "Status='Completed' where ID='" + lblID.Text.Trim() + "'";

            Database.executeQuery(sql1);

            obj.Show("Updated Sucessfully", "GPMemberFundsWorkList.aspx");
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("GPMemberFundsWorkList.aspx");
        }
    }
}