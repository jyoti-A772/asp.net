﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;

namespace E_Gram_Panchayat.WebPages.GPMember
{
    public partial class GPMemberWorkStatusAdd : System.Web.UI.Page
    {
        readyclass obj = new readyclass();

        protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
        {
            if (flPic.FileBytes.Length > 9437184)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lblID.Text = Request.QueryString["WorkID"].ToString();
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("GPMemberFundsWorkDetails.aspx?ID=" + lblID.Text.Trim());
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (flPic.HasFile)
            {
                int ID = obj.autoid("tblWorkStatus", "ID");

                string AdsFile = Guid.NewGuid().ToString() + Path.GetExtension(flPic.FileName);
                //flUploadPic.SaveAs(Request.PhysicalApplicationPath + "ParticipantImage\\" + AdsFile);

                flPic.SaveAs(Server.MapPath("~") + "WebPages/WorkStatusPic/" + AdsFile);

                string path = "../WorkStatusPic/" + AdsFile;

                string sql = "insert into tblWorkStatus(ID,WorkID,Date,WorkDescription,Pic) ";
                sql = sql + "Values('" + ID + "','" + lblID.Text.Trim() + "', ";
                sql = sql + "'" + DateTime.Now.ToShortDateString() + "','" + txtWorkDescription.Text.Trim() + "', ";
                sql = sql + "'" + path + "')";

                Database.executeQuery(sql);

                obj.Show("Saved Successfully", "GPMemberFundsWorkDetails.aspx?ID=" + lblID.Text.Trim());
            }
            else
            {
                readyclass.errormessage(lblerror, "Please select Image");
            }
        }
    }
}