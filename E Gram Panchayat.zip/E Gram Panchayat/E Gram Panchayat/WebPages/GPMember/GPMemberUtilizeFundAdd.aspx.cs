﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;

namespace E_Gram_Panchayat.WebPages.GPMember
{
    public partial class GPMemberUtilizeFundAdd : System.Web.UI.Page
    {
        readyclass obj = new readyclass();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lblGPID.Text = Session["UserID"].ToString();

                string sql = "Select GramPanchayath,AvailableFund from tblGramPanchayath where Mobile='" + lblGPID.Text.Trim() + "'";
                SqlDataReader dr = Database.getDataReader(sql);
                if (dr.Read())
                {
                    lblGramPanchayath.Text = dr[0].ToString().Trim();
                    lblAvailableFund.Text = dr[1].ToString().Trim();
                }
                dr.Close();

                sql = "Select distinct(Category) from tblCategory";
                obj.filllist(ddlCategory, sql);
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("GPMemberFundsList.aspx");
        }

        protected void btnAddFund_Click(object sender, EventArgs e)
        {
            int id = obj.autoid("tblUtilizedFunds", "ID");

            string sql = "insert into tblUtilizedFunds (ID,GramPanchayath,GPID,Category,WorkName,UtilizedAmount,UtilizedDate,Status) ";
            sql = sql + "Values(" + id + ", '" + lblGramPanchayath.Text.Trim() + "', ";
            sql = sql + "'" + lblGPID.Text.Trim() + "','" + ddlCategory.SelectedValue + "','" + txtWorkName.Text.Trim() + "', ";
            sql = sql + "'" + txtAmount.Text.Trim() + "', ";
            sql = sql + "'" + DateTime.Now.ToShortDateString() + "','Running')";
            Database.executeQuery(sql);

            sql = "Update tblGramPanchayath set ";
            sql = sql + "AvailableFund=AvailableFund-" + txtAmount.Text.Trim() + " where Mobile='" + lblGPID.Text.Trim() + "'";
            Database.executeQuery(sql);

            obj.Show("Saved sucessfully", "GPMemberFundsList.aspx");
        }
    }
}