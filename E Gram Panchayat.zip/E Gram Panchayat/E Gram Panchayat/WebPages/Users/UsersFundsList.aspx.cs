﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;

namespace E_Gram_Panchayat.WebPages.Users
{
    public partial class UsersFundsList : System.Web.UI.Page
    {
        readyclass obj = new readyclass();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                fillAvailableAmount();

                fillFundList();

                fillUtilizedFundList();
            }
        }

        private void fillAvailableAmount()
        {
            string sql = "select AvailableFund from tblGramPanchayath where Mobile='" + Session["GPID"].ToString() + "'";
            SqlDataReader dr = Database.getDataReader(sql);
            if (dr.Read())
            {
                lblAvailableFund.Text = dr[0].ToString().Trim();
            }
            dr.Close();
        }

        private void fillFundList()
        {
            string sql = "Select * from tblFunds where GPID='" + Session["GPID"].ToString() + "'";
            obj.fill(grdFunds, sql, lblerror);
        }

        private void fillUtilizedFundList()
        {
            string sql = "Select * from tblUtilizedFunds where GPID='" + Session["GPID"].ToString() + "'";
            obj.fill(grdUtilizedFunds, sql, lblerror);
        }

    }
}