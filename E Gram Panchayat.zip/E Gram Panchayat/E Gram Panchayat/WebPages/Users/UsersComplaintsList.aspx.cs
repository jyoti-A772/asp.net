﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace E_Gram_Panchayat.WebPages.Users
{
    public partial class UsersComplaintsList : System.Web.UI.Page
    {
        readyclass obj = new readyclass();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string sql = "Select * from tblComplaints where UserID='" + Session["UserID"].ToString() + "'";
                obj.fill(grdComplaints, sql, lblerror);
            }
        }
    }
}