﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;

namespace E_Gram_Panchayat.WebPages.Users
{
    public partial class UsersInfo : System.Web.UI.Page
    {
        readyclass obj = new readyclass();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                string sql = "Select distinct(District) from tblGramPanchayath";
                obj.filllist(ddlDistrict, sql);

                lblMobile.Text = Session["UserID"].ToString();
                pagerefresh();

                btnUpdate.Visible = false;
                btnEdit.Visible = true;
                btnCancel.Visible = false;
            }
        }

        protected void ddlDistrict_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sql = "Select distinct(Taluk) from tblGramPanchayath where District='" + ddlDistrict.SelectedValue + "'";
            obj.filllist(ddlTaluk, sql);
        }

        protected void ddlTaluk_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sql = "Select distinct(GramPanchayath) from tblGramPanchayath where District='" + ddlDistrict.SelectedValue + "' and Taluk='" + ddlTaluk.SelectedValue + "'";
            obj.filllist(ddlGramPanchayath, sql);
        }

        protected void ddlGramPanchayath_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sql = "Select distinct(Mobile) from tblGramPanchayath where District='" + ddlDistrict.SelectedValue + "' and Taluk='" + ddlTaluk.SelectedValue + "' and GramPanchayath='" + ddlGramPanchayath.SelectedValue + "'";
            SqlDataReader dr = Database.getDataReader(sql);
            if (dr.Read())
            {
                lblGPID.Text = dr[0].ToString().Trim();
            }
            dr.Close();
        }

        private void pagerefresh()
        {
            String GramPanchayath = null, Taluk = null;
            string sql = "select * from tblUsers where Mobile='" + lblMobile.Text + "'";
            SqlDataReader dr = Database.getDataReader(sql);
            if (dr.Read())
            {
                txtUserName.Text = dr[1].ToString().Trim();
                txtAddressLine1.Text = dr[2].ToString().Trim();
                txtAddressLine2.Text = dr[3].ToString().Trim();
                GramPanchayath = dr[4].ToString().Trim();
                lblGPID.Text = dr[5].ToString().Trim();
                Taluk = dr[6].ToString().Trim();
                ddlDistrict.SelectedValue = dr[7].ToString().Trim();
                lblMobile.Text = dr[8].ToString().Trim();
            }
            dr.Close();

            obj.makereadonly(Page.Controls);

            ddlDistrict_SelectedIndexChanged(this, new EventArgs());
            ddlTaluk.SelectedValue = Taluk;

            ddlTaluk_SelectedIndexChanged(this, new EventArgs());
            ddlGramPanchayath.SelectedValue = GramPanchayath;
        }

        protected void btnEdit_Click(object sender, EventArgs e)
        {
            obj.makeeditable(Page.Controls);

            btnUpdate.Visible = true;
            btnEdit.Visible = false;
            btnCancel.Visible = true;

        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            string sql = "Update tblUsers SET ";
            sql = sql + "UserName = '" + txtUserName.Text.Trim() + "', ";
            sql = sql + "AddressLine1 = '" + txtAddressLine1.Text + "', ";
            sql = sql + "AddressLine2 = '" + txtAddressLine2.Text.Trim() + "', ";
            sql = sql + "GramPanchayath = '" + ddlGramPanchayath.SelectedValue + "', ";
            sql = sql + "GPID = '" + lblGPID.Text.Trim() + "', ";
            sql = sql + "Taluk = '" + ddlTaluk.SelectedValue + "', ";
            sql = sql + "District = '" + ddlDistrict.SelectedValue + "' ";
            sql = sql + " Where Mobile = '" + lblMobile.Text.Trim() + "'";

            Database.executeQuery(sql);

            readyclass.errormessage(lblerror, "Data is Updated Successfully");
            pagerefresh();

            btnUpdate.Visible = false;
            btnEdit.Visible = true;
            btnCancel.Visible = false;
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            pagerefresh();
            btnUpdate.Visible = false;
            btnEdit.Visible = true;
            btnCancel.Visible = false;
        }

    }
}