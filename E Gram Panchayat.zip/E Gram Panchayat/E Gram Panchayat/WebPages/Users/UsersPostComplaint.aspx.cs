﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.IO;

namespace E_Gram_Panchayat.WebPages.Users
{
    public partial class UsersPostComplaint : System.Web.UI.Page
    {
        readyclass obj = new readyclass();

        protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
        {
            if (flPic.FileBytes.Length > 9437184)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lblWorkID.Text = Request.QueryString["ID"].ToString();
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("UsersFundsWorkDetails.aspx?ID=" + lblWorkID.Text.Trim());
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (flPic.HasFile)
            {
                int ID = obj.autoid("tblComplaints", "ID");

                string AdsFile = Guid.NewGuid().ToString() + Path.GetExtension(flPic.FileName);
                //flUploadPic.SaveAs(Request.PhysicalApplicationPath + "ParticipantImage\\" + AdsFile);

                flPic.SaveAs(Server.MapPath("~") + "WebPages/ComplaintsPic/" + AdsFile);

                string path = "../ComplaintsPic/" + AdsFile;

                string sql = "insert into tblComplaints(ID,WorkID,Subject,Description,Pic,Status,UserID,GPID) ";
                sql = sql + "Values('" + ID + "','" + lblWorkID.Text.Trim() + "', ";
                sql = sql + "'" +txtSubject.Text.Trim() + "','" + txtDescription.Text.Trim() + "', ";
                sql = sql + "'" + path + "','New','" + Session["UserID"].ToString() + "','" + Session["GPID"].ToString() + "')";

                Database.executeQuery(sql);

                obj.Show("Posted Successfully", "UsersFundsWorkDetails.aspx?ID=" + lblWorkID.Text.Trim());
            }
            else
            {
                readyclass.errormessage(lblerror, "Please select Image");
            }
        }
    }
}