﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;

namespace E_Gram_Panchayat.WebPages.Users
{
    public partial class UsersFundsWorkDetails : System.Web.UI.Page
    {
        readyclass obj = new readyclass();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lblID.Text = Request.QueryString["ID"].ToString();

                fillUtilizedFundDetails();

                fillWOrkStatus();
            }
        }

        private void fillUtilizedFundDetails()
        {
            string sql = "Select * from tblUtilizedFunds where ID='" + lblID.Text.Trim() + "'";
            SqlDataReader dr = Database.getDataReader(sql);
            if (dr.Read())
            {
                lblID.Text = dr[0].ToString().Trim();
                lblGramPanchayath.Text = dr[1].ToString().Trim();
                lblGPID.Text = dr[2].ToString().Trim();
                lblCategory.Text = dr[3].ToString().Trim();
                lblWorkName.Text = dr[4].ToString().Trim();
                lblUtilizedAmount.Text = dr[5].ToString().Trim();
                lblUtilizedDate.Text = DateTime.Parse(dr[6].ToString().Trim()).ToShortDateString();
                lblStatus.Text = dr[7].ToString().Trim();
            }
            dr.Close();
        }

        private void fillWOrkStatus()
        {
            string sql = "Select * from tblWorkStatus where WorkID='" + lblID.Text.Trim() + "'";
            obj.fill(grdWorkPics, sql, lblerror);
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("UsersFundsWorkList.aspx");
        }

        protected void btnPostComplaint_Click(object sender, EventArgs e)
        {
            Response.Redirect("UsersPostComplaint.aspx?ID="+lblID.Text.Trim());
        }
    }
}