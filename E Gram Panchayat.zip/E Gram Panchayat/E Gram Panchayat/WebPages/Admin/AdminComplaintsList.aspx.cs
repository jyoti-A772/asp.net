﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace E_Gram_Panchayat.WebPages.Admin
{
    public partial class AdminComplaintsList : System.Web.UI.Page
    {
        readyclass obj = new readyclass();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string sql = "select distinct(Status) from tblComplaints";
                obj.filllist(ddlStatus, sql);
            }
        }

        private void fill()
        {
            string sql = "Select * from tblComplaints where Status='" + ddlStatus.SelectedValue + "'";
            obj.fill(grdComplaints, sql, lblerror);
        }

        protected void ddlStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            fill();
        }

    }
}