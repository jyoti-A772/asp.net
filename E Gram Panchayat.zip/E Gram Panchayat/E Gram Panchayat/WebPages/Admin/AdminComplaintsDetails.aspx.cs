﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;

namespace E_Gram_Panchayat.WebPages.Admin
{
    public partial class AdminComplaintsDetails : System.Web.UI.Page
    {
        readyclass obj = new readyclass();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lblID.Text = Request.QueryString["ID"].ToString();

                fillComplaintDetails();

                fillGramPanchayathDetails();

                fillUserDetails();
            }
        }

        private void fillComplaintDetails()
        {
            string sql = "Select * from tblComplaints where ID='" + lblID.Text.Trim() + "'";
            SqlDataReader dr = Database.getDataReader(sql);
            if (dr.Read())
            {
                lblID.Text = dr["ID"].ToString().Trim();
                lblWorkID.Text = dr["WorkID"].ToString().Trim();
                lblSubject.Text = dr["Subject"].ToString().Trim();
                lblDescription.Text = dr["Description"].ToString().Trim();
                imgComplaint.ImageUrl = dr["Pic"].ToString().Trim();
                lblStatus.Text = dr["Status"].ToString().Trim();
                lblUMobile.Text = dr["UserID"].ToString().Trim();
                lblMobile.Text = dr["GPID"].ToString().Trim();
            }
            dr.Close();
        }


        private void fillGramPanchayathDetails()
        {
            string sql = "Select * from tblGramPanchayath where Mobile='" + lblMobile.Text.Trim() + "'";
            SqlDataReader dr = Database.getDataReader(sql);
            if (dr.Read())
            {
                lblGramPanchayath.Text = dr["GramPanchayath"].ToString().Trim();
                lblVillageArea.Text = dr["VillageArea"].ToString().Trim();
                lblTaluk.Text = dr["Taluk"].ToString().Trim();
                lblDistrict.Text = dr["District"].ToString().Trim();
                lblGPMember.Text = dr["GPMember"].ToString().Trim();
                lblMobile.Text = dr["Mobile"].ToString().Trim();
            }
            dr.Close();
        }


        private void fillUserDetails()
        {
            string sql = "Select * from tblUsers where Mobile='" + lblUMobile.Text.Trim() + "'";
            SqlDataReader dr = Database.getDataReader(sql);
            if (dr.Read())
            {
                lblUserName.Text = dr["UserName"].ToString().Trim();
                lblUAddressLine1.Text = dr["AddressLine1"].ToString().Trim();
                lblUAddressLine2.Text = dr["AddressLine2"].ToString().Trim();
                lblUGramPanchayath.Text = dr["GramPanchayath"].ToString().Trim();
                lblUTaluk.Text = dr["Taluk"].ToString().Trim();
                lblUDistrict.Text = dr["District"].ToString().Trim();
                lblUMobile.Text = dr["Mobile"].ToString().Trim();
            }
            dr.Close();
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdminComplaintsList.aspx");
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            string sql1 = "Delete from tblComplaints where ID='" + lblID.Text.Trim() + "'";

            Database.executeQuery(sql1);

            obj.Show("Deleted successfully", "AdminComplaintsList.aspx");
        }

        protected void btnProcessed_Click(object sender, EventArgs e)
        {
            string sql1 = "Update tblComplaints set Status='Processed' where ID='" + lblID.Text.Trim() + "'";

            Database.executeQuery(sql1);

            obj.Show("Update successfully", "AdminComplaintsList.aspx");
        }
    }
}