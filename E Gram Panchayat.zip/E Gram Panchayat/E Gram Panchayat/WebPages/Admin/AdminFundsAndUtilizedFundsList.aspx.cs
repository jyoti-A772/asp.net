﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;

namespace E_Gram_Panchayat.WebPages.Admin
{
    public partial class AdminFundsAndUtilizedFundsList : System.Web.UI.Page
    {
        readyclass obj = new readyclass();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string sql = "Select distinct(District) from tblGramPanchayath";
                obj.filllist(ddlDistrict, sql);
            }
        }

        protected void ddlTaluk_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sql = "Select distinct(GramPanchayath) from tblGramPanchayath where District='" + ddlDistrict.SelectedValue + "' and Taluk='" + ddlTaluk.SelectedValue + "'";
            obj.filllist(ddlGramPanchayath, sql);
        }

        protected void ddlDistrict_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sql = "Select distinct(Taluk) from tblGramPanchayath where District='" + ddlDistrict.SelectedValue + "'";
            obj.filllist(ddlTaluk, sql);
        }

        protected void ddlGramPanchayath_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sql = "Select distinct(Mobile) from tblGramPanchayath where District='" + ddlDistrict.SelectedValue + "' and Taluk='" + ddlTaluk.SelectedValue + "' and GramPanchayath='" + ddlGramPanchayath.SelectedValue + "'";
            SqlDataReader dr = Database.getDataReader(sql);
            if (dr.Read())
            {
                lblGPID.Text = dr[0].ToString();
            }
            dr.Close();

            fillAvailableAmount();

            fillFundList();

            fillUtilizedFundList();
        }

        private void fillAvailableAmount()
        {
            string sql = "select AvailableFund from tblGramPanchayath where Mobile='" + lblGPID.Text.Trim() + "'";
            SqlDataReader dr = Database.getDataReader(sql);
            if (dr.Read())
            {
                lblAvailableFund.Text = dr[0].ToString().Trim();
            }
            dr.Close();
        }

        private void fillFundList()
        {
            string sql = "Select * from tblFunds where GPID='" + lblGPID.Text.Trim() + "'";
            obj.fill(grdFunds, sql, lblerror);
        }

        private void fillUtilizedFundList()
        {
            string sql = "Select * from tblUtilizedFunds where GPID='" + lblGPID.Text.Trim() + "'";
            obj.fill(grdUtilizedFunds, sql, lblerror);
        }

    }
}