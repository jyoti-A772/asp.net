﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace E_Gram_Panchayat.WebPages.Admin
{
    public partial class AdminGramPanchayatList : System.Web.UI.Page
    {
        string sql;
        readyclass obj = new readyclass();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                fill();
            }
        }

        private void fill()
        {
            sql = "select * from tblGramPanchayath where GramPanchayath LIKE '%" + txtGramPanchayath.Text.Trim() + "%'";
            obj.fill(grdGrampanchayath, sql, lblerror);
        }

        protected void btnAddNew_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdminGramPanchayatDetails.aspx");
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            fill();
        }
    }
}