﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;

namespace E_Gram_Panchayat.WebPages.Admin
{
    public partial class AdminGramPanchayatDetails : System.Web.UI.Page
    {
        readyclass obj = new readyclass();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string sql = "Select distinct(District) from tblTaluk";
                obj.filllist(ddlDistrict, sql);

                lblID.Text = Request.QueryString["ID"];
                if (lblID.Text.Trim() != "")
                {
                    pagerefresh();
                    obj.makereadonly(Page.Controls);
                    btnSave.Visible = false;
                    btnUpdate.Visible = false;
                    btnEdit.Visible = true;
                    btnCancel.Visible = true;
                    btnDelete.Visible = true;
                }
                else
                {
                    obj.makeeditable(Page.Controls);
                    btnSave.Visible = true;
                    btnUpdate.Visible = false;
                    btnEdit.Visible = false;
                    btnCancel.Visible = true;
                    btnDelete.Visible = false;
                }

                btnDelete.Attributes.Add("onclick", "return confirm();");
            }
        }

        private void pagerefresh()
        {
            string Taluk = null;
            string District = null;

            string sql = "select * from tblGramPanchayath where ID='" + lblID.Text.Trim() + "'";
            SqlDataReader dr = Database.getDataReader(sql);
            if (dr.Read())
            {
                lblID.Text = dr[0].ToString().Trim();
                txtGramPanchayath.Text = dr[1].ToString().Trim();
                txtVillageArea.Text = dr[2].ToString().Trim();
                Taluk = dr[3].ToString().Trim();
                District = dr[4].ToString().Trim();
                txtGPMember.Text = dr[5].ToString().Trim();
                txtMobile.Text = dr[6].ToString().Trim();
            }
            dr.Close();

            ddlDistrict.SelectedValue = District;

            ddlDistrict_SelectedIndexChanged(this, new EventArgs());
            ddlTaluk.SelectedValue = Taluk;
        }

        protected void ddlDistrict_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sql = "Select distinct(Taluk) from tblTaluk where District='" + ddlDistrict.SelectedValue + "'";
            obj.filllist(ddlTaluk, sql);
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {

            string sql = "select * from tblLogin where UserID='" + txtMobile.Text.Trim() + "'";
            if (obj.checkduplicate(sql))
            {
                readyclass.errormessage(lblerror, "Mobile already exist");
            }
            else
            {

                string Userid = "GP-" + obj.getid("tblGramPanchayath", "ID").ToString("0000");

                sql = "insert into tblGramPanchayath(ID,GramPanchayath,VillageArea,Taluk,District,GPMember,Mobile,AvailableFund) ";
                sql = sql + "Values('" + Userid + "','" + txtGramPanchayath.Text.Trim() + "', ";
                sql = sql + "'" + txtVillageArea.Text.Trim() + "','" + ddlTaluk.SelectedValue + "',  ";
                sql = sql + "'" + ddlDistrict.SelectedValue + "','" + txtGPMember.Text.Trim() + "', ";
                sql = sql + "'" + txtMobile.Text.Trim() + "',0)";

                Database.executeQuery(sql);

                string pwd = obj.generateOTP();


                sql = "insert into tblLogin (UserID,Password,UserType) ";
                sql = sql + "Values('" + txtMobile.Text.Trim() + "', '" + pwd + "','GPMember')";

                Database.executeQuery(sql);

                string msg = "You can login to the Portal by using User ID:" + txtMobile.Text.Trim() + ". and Password is : " + pwd;
                string mobile = txtMobile.Text.Trim();

                obj.sendSMS(msg, mobile);

                obj.Show("Saved Successfully" + msg, "AdminGramPanchayatList.aspx");
            }
        }

        protected void btnEdit_Click(object sender, EventArgs e)
        {
            obj.makeeditable(Page.Controls);

            txtMobile.ReadOnly = true;

            btnEdit.Visible = false;
            btnUpdate.Visible = true;
            btnCancel.Visible = true;
            btnSave.Visible = false;
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            string sql = "Update tblGramPanchayath SET ";
            sql = sql + "GramPanchayath = '" + txtGramPanchayath.Text.Trim() + "', ";
            sql = sql + "VillageArea = '" + txtVillageArea.Text + "', ";
            sql = sql + "Taluk = '" + ddlTaluk.SelectedValue + "', ";
            sql = sql + "District = '" + ddlDistrict.SelectedValue + "', ";
            sql = sql + "GPMember = '" + txtGPMember.Text.Trim() + "' ";
            sql = sql + " Where ID = '" + lblID.Text.Trim() + "'";

            Database.executeQuery(sql);

            obj.Show("Updated Successfully", "AdminGramPanchayatList.aspx");
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdminGramPanchayatList.aspx");

        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            if (lblID.Text.Trim() == "")
                readyclass.errormessage(lblerror, "Select Gram Panchayath to delete");
            else
            {
                string sql = "delete from tblGramPanchayath where ID = '" + lblID.Text.Trim() + "'";
                Database.executeQuery(sql);

                sql = "delete from tblLogin where UserID = '" + txtMobile.Text.Trim() + "'";
                Database.executeQuery(sql);

                obj.Show("Deleted Successfully", "AdminGramPanchayatList.aspx");
            }
        }
    }
}