﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;

namespace E_Gram_Panchayat.WebPages.Admin
{
    public partial class AdminFundsAdd : System.Web.UI.Page
    {
        readyclass obj = new readyclass();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string sql = "Select distinct(District) from tblGramPanchayath";
                obj.filllist(ddlDistrict, sql);
            }
        }

        protected void ddlTaluk_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sql = "Select distinct(GramPanchayath) from tblGramPanchayath where District='" + ddlDistrict.SelectedValue + "' and Taluk='" + ddlTaluk.SelectedValue + "'";
            obj.filllist(ddlGramPanchayath, sql);
        }

        protected void ddlDistrict_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sql = "Select distinct(Taluk) from tblGramPanchayath where District='" + ddlDistrict.SelectedValue + "'";
            obj.filllist(ddlTaluk, sql);
        }

        protected void ddlGramPanchayath_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sql = "Select distinct(Mobile) from tblGramPanchayath where District='" + ddlDistrict.SelectedValue + "' and Taluk='" + ddlTaluk.SelectedValue + "' and GramPanchayath='" + ddlGramPanchayath.SelectedValue + "'";
            SqlDataReader dr = Database.getDataReader(sql);
            if (dr.Read())
            {
                lblGPID.Text = dr[0].ToString();
            }
            dr.Close();
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdminFundsList.aspx");
        }

        protected void btnAddFund_Click(object sender, EventArgs e)
        {
            int id = obj.autoid("tblFunds", "ID");

            string sql = "insert into tblFunds (ID,GramPanchayath,GPID,FundAmount,ReleasedDate) ";
            sql = sql + "Values(" + id + ", '" + ddlGramPanchayath.SelectedValue + "', ";
            sql = sql + "'" + lblGPID.Text.Trim() + "','" + txtAmount.Text.Trim() + "', ";
            sql = sql + "'" + DateTime.Now.ToShortDateString() + "')";
            Database.executeQuery(sql);

            sql = "Update tblGramPanchayath set ";
            sql = sql + "AvailableFund=AvailableFund+" + txtAmount.Text.Trim() + " where Mobile='" + lblGPID.Text.Trim() + "'";
            Database.executeQuery(sql);

            obj.Show("Saved sucessfully", "AdminFundsList.aspx");
        }

    }
}