﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;

namespace E_Gram_Panchayat.WebPages.Admin
{
    public partial class AdminFundsList : System.Web.UI.Page
    {
        readyclass obj = new readyclass();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string sql = "Select distinct(District) from tblGramPanchayath";
                obj.filllist(ddlDistrict, sql);
            }
        }

        protected void ddlTaluk_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sql = "Select distinct(GramPanchayath) from tblGramPanchayath where District='" + ddlDistrict.SelectedValue + "' and Taluk='" + ddlTaluk.SelectedValue + "'";
            obj.filllist(ddlGramPanchayath, sql);
        }

        protected void ddlDistrict_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sql = "Select distinct(Taluk) from tblGramPanchayath where District='" + ddlDistrict.SelectedValue + "'";
            obj.filllist(ddlTaluk, sql);
        }

        protected void ddlGramPanchayath_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sql = "Select distinct(Mobile) from tblGramPanchayath where District='" + ddlDistrict.SelectedValue + "' and Taluk='" + ddlTaluk.SelectedValue + "' and GramPanchayath='" + ddlGramPanchayath.SelectedValue + "'";
            SqlDataReader dr = Database.getDataReader(sql);
            if (dr.Read())
            {
                lblGPID.Text = dr[0].ToString();
            }
            dr.Close();

            sql = "Select * from tblFunds where GPID='" + lblGPID.Text.Trim() + "'";
            obj.fill(grdFunds, sql, lblerror);
        }

        protected void btnAddFund_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdminFundsAdd.aspx");
        }

        protected void grdFunds_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            string release;
            release = grdFunds.DataKeys[e.RowIndex].Values[0].ToString();


            string GPID = null;
            string Amount = null;

            string sql = "Select GPID,FundAmount from tblFunds where ID='" + release + "'";
            SqlDataReader dr = Database.getDataReader(sql);
            if (dr.Read())
            {
                GPID = dr[0].ToString().Trim();
                Amount = dr[1].ToString().Trim();
            }
            dr.Close();

            sql = "Update tblGramPanchayath set ";
            sql = sql + "AvailableFund=AvailableFund-" + Amount + " where Mobile='" + GPID + "'";
            Database.executeQuery(sql);

            sql = "delete from tblFunds where ID = " + release + "";
            Database.executeQuery(sql);

            ddlGramPanchayath_SelectedIndexChanged(this, new EventArgs());
        }

        protected void grdFunds_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                // reference the Delete LinkButton
                LinkButton db = (LinkButton)e.Row.Cells[2].Controls[0];

                db.OnClientClick = "return confirm('Are you certain you want to delete this?');";
            }
        }
    }
}