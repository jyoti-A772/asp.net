﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;

namespace E_Gram_Panchayat.WebPages.Admin
{
    public partial class AdminUsersDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lblID.Text = Request.QueryString["ID"].ToString();

                fillUserDetails();
            }
        }

        private void fillUserDetails()
        {
            string sql = "Select * from tblUsers where ID='" + lblID.Text.Trim() + "'";
            SqlDataReader dr = Database.getDataReader(sql);
            if (dr.Read())
            {
                lblUserName.Text = dr["UserName"].ToString().Trim();
                lblAddressLine1.Text = dr["AddressLine1"].ToString().Trim();
                lblAddressLine2.Text = dr["AddressLine2"].ToString().Trim();
                lblGramPanchayath.Text = dr["GramPanchayath"].ToString().Trim();
                lblGPID.Text = dr["GPID"].ToString().Trim();
                lblTaluk.Text = dr["Taluk"].ToString().Trim();
                lblDistrict.Text = dr["District"].ToString().Trim();
                lblMobile.Text = dr["Mobile"].ToString().Trim();
            }
            dr.Close();
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("AdminUsersList.aspx");
        }

    }
}