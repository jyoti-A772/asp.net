﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;

namespace E_Gram_Panchayat.WebPages
{
    public partial class UserRegistration : System.Web.UI.Page
    {
        readyclass obj = new readyclass();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string sql = "Select distinct(District) from tblGramPanchayath";
                obj.filllist(ddlDistrict, sql);
            }
        }

        protected void ddlDistrict_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sql = "Select distinct(Taluk) from tblGramPanchayath where District='" + ddlDistrict.SelectedValue + "'";
            obj.filllist(ddlTaluk, sql);
        }

        protected void ddlTaluk_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sql = "Select distinct(GramPanchayath) from tblGramPanchayath where District='" + ddlDistrict.SelectedValue + "' and Taluk='" + ddlTaluk.SelectedValue + "'";
            obj.filllist(ddlGramPanchayath, sql);
        }

        protected void ddlGramPanchayath_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sql = "Select distinct(Mobile) from tblGramPanchayath where District='" + ddlDistrict.SelectedValue + "' and Taluk='" + ddlTaluk.SelectedValue + "' and GramPanchayath='" + ddlGramPanchayath.SelectedValue + "'";
            SqlDataReader dr = Database.getDataReader(sql);
            if (dr.Read())
            {
                lblGPID.Text = dr[0].ToString().Trim();
            }
            dr.Close();
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            string sql1 = "select * from tblLogin where UserID='" + txtMobile.Text.Trim() + "'";
            bool falg = obj.checkduplicate(sql1);

            if (falg == true)
                readyclass.errormessage(lblerror, "This Mobile already exist");
            else
            {
                string Userid = "US-" + obj.getid("tblUsers", "ID").ToString("0000");

                string sql = "insert into tblUsers(ID,UserName,AddressLine1,AddressLine2,GramPanchayath,GPID,Taluk,District,Mobile) ";
                sql = sql + "Values('" + Userid + "','" + txtUserName.Text.Trim() + "',";
                sql = sql + "'" + txtAddressLine1.Text.Trim() + "','" + txtAddressLine2.Text.Trim() + "',  ";
                sql = sql + "'" + ddlGramPanchayath.SelectedValue + "','" + lblGPID.Text.Trim() + "', ";
                sql = sql + "'" + ddlTaluk.SelectedValue + "','" + ddlDistrict.SelectedValue + "', ";
                sql = sql + "'" + txtMobile.Text.Trim() + "')";

                Database.executeQuery(sql);


                string pwd = obj.generateOTP();

                sql = "insert into tblLogin(UserID,Password,UserType) ";
                sql = sql + "Values('" + txtMobile.Text.Trim() + "','" + pwd + "',";
                sql = sql + "'Users')";

                Database.executeQuery(sql);

                string msg = "Your Login Code " + txtMobile.Text.Trim() + " Password is " + pwd;

                string mobile = txtMobile.Text.Trim();
                obj.sendSMS(msg, mobile);

                obj.Show("Your Registration Request is accepted Successfully. " + msg, "Login.aspx");
            }
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("Login.aspx");
        }
    }
}